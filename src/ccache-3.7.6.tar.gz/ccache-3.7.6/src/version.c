extern const char CCACHE_VERSION[]; const char CCACHE_VERSION[] = "3.7.6";
